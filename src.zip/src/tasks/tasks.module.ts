import { Module } from '@nestjs/common';

@Module({
  providers: [],
  exports: [],
})
export class TasksModule {} 