export { Task } from './task.abstract';
export { TaskResult } from './types/task-result.interface';
export { taskA } from './task-a';
export { taskB } from './task-b';
export { taskC } from './task-c';
export { taskD } from './task-d';
export { taskE } from './task-e';

import { taskA } from './task-a';
import { taskB } from './task-b';
import { taskC } from './task-c';
import { taskD } from './task-d';
import { taskE } from './task-e';

export const tasks = [taskA, taskB, taskC, taskD, taskE];